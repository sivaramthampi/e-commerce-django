from django.urls import path
from . import views
urlpatterns = [
    path("call", views.call),
    path("add", views.add),
    path("homepage",views.homepage),
    path("db",views.dbitemsdisp),
    path("productdetail/<str:reqid>",views.product),
    path("addtocart",views.addtocart),
    path("mycart",views.viewcart)
]