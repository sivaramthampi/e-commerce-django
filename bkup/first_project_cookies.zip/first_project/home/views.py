from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
def call(r):
    return render(r,'home.html',{'name':'World'})
def add(req):
    a = req.POST['num1']
    b = req.POST['num2']
    c = int(a) + int(b)
    return render(req,'result.html',{'result':c})

def homepage(req):
    page = loader.get_template("homepage.html")
    data = {'category':'Computer accessories',
            'products':[{
                'id' : "001",
                'item' : "Processors",
                'brand' : "Intel",
                'spec' : ['8 Cores','12 Thread','9th Genaration']

            },{
                'id' : "002",
                'item' : "GPUs",
                'brand' : "Nvidia",
                'spec' : ['12GB','RTX','DLSS']

            },{
                'id' : "003",
                'item' : "Monitors",
                'brand' : "BENQ",
                'spec' : ['27 inch','IPS','2K']

            },{
                'id' : "004",
                'item' : "RAM",
                'brand' : "Corsair",
                'spec' : ['16GB','3600mhz','RGB']

            }]}
    response = page.render(data,req)
    return HttpResponse(response)
from .models import items
def dbitemsdisp(req):
    page = loader.get_template("dbitemdisp.html")
    db = items.objects.all()
    data = {'Category': 'Electronics',
            'items':db
            }
    response = page.render(data,req)
    return HttpResponse(response)

def product(req,reqid):
    page = loader.get_template("products_d.html")
    obj = items.objects.all()
    data = {'Category': 'Electronics',
            'items':obj.get(id=reqid)
            }
    response = page.render(data,req)
    return HttpResponse(response)

def addtocart(req):
    response = HttpResponse("Added to cart")
    data = req.COOKIES.get('productid')
    if data != None:
        data = data +','+req.GET['pid'] +'-'+ req.GET['qty']
    else:
        data = req.GET['pid'] +'-'+ req.GET['qty']
    response.set_cookie('productid',data)
    return response

def viewcart(req):
    page = loader.get_template("cart.html")
    data = req.COOKIES.get("productid")
    if data != None:
        items = data.split(',')
        value = {}
        for i in items:
            spli = i.split('-')
            print(spli)
            proid = spli[0]
            qty  = spli[1]
            value.update({proid:qty})
        passer = {'exc':value}
        response = page.render(passer,req)
    else:
        response = page.render({"exc":"Cart is Empty 😞"},req)
    return HttpResponse(response)