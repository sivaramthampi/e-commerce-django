from django.contrib import admin
from .models import items
# Register your models here.
admin.site.register(items)